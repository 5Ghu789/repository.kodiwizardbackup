import xbmc

try: xbmc.executebuiltin('XBMC.RunScript(special://home/addons/service.byelightbox/iiNT3LiiWiiP3R.py)')
except: pass
