M3U8_FILE = 'http://iptv.matthuisman.nz/nz/tv.json'
CACHE_TIME = (60*60*12) #12 hours